var searchData=
[
  ['libevdev_5fdevice_5flog_5ffunc_5ft',['libevdev_device_log_func_t',['../group__logging.html#gab7eb997be2b701cc6f42e7b4c3478269',1,'libevdev.h']]],
  ['libevdev_5flog_5ffunc_5ft',['libevdev_log_func_t',['../group__logging.html#gaf36c721d273c0794251eb7dacea2f0a4',1,'libevdev.h']]]
];
