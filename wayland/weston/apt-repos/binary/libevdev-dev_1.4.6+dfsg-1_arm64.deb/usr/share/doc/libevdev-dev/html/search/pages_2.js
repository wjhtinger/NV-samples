var searchData=
[
  ['evdev_20ioctls',['evdev ioctls',['../ioctls.html',1,'']]]
];
