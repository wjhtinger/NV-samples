var searchData=
[
  ['initialization_20and_20setup',['Initialization and setup',['../group__init.html',1,'']]]
];
