var searchData=
[
  ['querying_20device_20capabilities',['Querying device capabilities',['../group__bits.html',1,'']]]
];
